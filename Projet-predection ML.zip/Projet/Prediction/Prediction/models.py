# Régression Linéaire Multiple
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import copy

# Importer le dataset
dataset = pd.read_csv('50_Startups.csv')
dataset1=copy.deepcopy(dataset) 

dataset.info()
dataset.describe()

mean1=dataset['R&D Spend'].mean()
mean2=dataset['Marketing Spend'].mean()

mean1=str(round(mean1, 2))
mean2=str(round(mean2, 2))

hist=dataset['R&D Spend'].hist()

for i in range(len(dataset)):
    if dataset.loc[i, 'R&D Spend'] == 0:
        dataset.loc[i, 'R&D Spend']=mean1
    else:
        continue

hist1=dataset['Marketing Spend'].hist()

for i in range(len(dataset)):
    if dataset.loc[i, 'Marketing Spend'] == 0:
        dataset.loc[i, 'Marketing Spend']=mean2
    else:
        continue
    
    
    
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

# Gérer les variables catégoriques
transformer = ColumnTransformer(
    transformers=[
        ("OneHot",        
         OneHotEncoder(), 
         [3]              
         )
    ],
    remainder='passthrough' 
)

X = transformer.fit_transform(X)    
    
# Diviser le dataset entre le Training set et le Test set

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

# Construction du modèle

regressor1 = LinearRegression()

regressor1.fit(X_train, y_train)

y_pred = regressor1.predict(X_test)

  
#y_pred2=regressor1.predict(np.array([[1,0,0, 130000, 140000, 300000]]))


regressor1.intercept_

regressor1.coef_


r2_score(y_test, y_pred)

'''s=regressor.score(X_test,y_test)
s'''

#save model
import pickle
filename = 'regressor1_model_test.sav'
pickle.dump(regressor1, open(filename, 'wb'))

# load the model from disk
loaded_model = pickle.load(open(filename, 'rb'))
result = loaded_model.score(X_test, y_test)
print(result)


#Pour le dataset avec des 0

X1 = dataset1.iloc[:, :-1].values
y1 = dataset1.iloc[:, -1].values

# Gérer les variables catégoriques
transformer = ColumnTransformer(
    transformers=[
        ("OneHot",        
         OneHotEncoder(), 
         [3]              
         )
    ],
    remainder='passthrough' 
)

X1 = transformer.fit_transform(X1)    
    
# Diviser le dataset entre le Training set et le Test set

X1_train, X1_test, y1_train, y1_test = train_test_split(X1, y1, test_size = 0.2, random_state = 0)

# Construction du modèle

regressor2 = LinearRegression()

regressor2.fit(X1_train, y1_train)

y_pred1 = regressor2.predict(X1_test)

  
#y_pred3=regressor2.predict(np.array([[1,0,0, 130000, 140000, 300000]]))


regressor2.intercept_

regressor2.coef_


r2_score(y1_test, y_pred1)

'''s1=regressor2.score(X1_test,y1_test)
s'''

#save model
import pickle
filename = 'regressor2_model_test.sav'
pickle.dump(regressor2, open(filename, 'wb'))

# load the model from disk
loaded_model = pickle.load(open(filename, 'rb'))
result = loaded_model.score(X1_test, y1_test)
print(result)