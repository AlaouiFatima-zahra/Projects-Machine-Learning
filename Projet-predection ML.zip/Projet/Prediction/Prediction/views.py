from django.shortcuts import render
import pickle
import os
import numpy as np


def index(request):
    return render(request,'templates/index.html')
    
def acceuil(request):
    return render(request,'templates/acceuil.html')
 
def prediction1(request):
    return render(request,'templates/model_predict.html')
    
def prediction2(request):
    return render(request,'templates/model2_predict.html')
    
def model1_predict(request):
    if request.method=="POST":
        rdspend=request.POST.get("RD Spend")       
        administration=request.POST.get("Administration")
        marketingspend=request.POST.get("Marketing Spend")
        state=request.POST.get("State")
        if state=='California':
            ypred1=[[0,0,1, rdspend, administration, marketingspend]]
        if state=='New York':
            ypred1=[[0,1,0, rdspend, administration, marketingspend]]
        if state=='Florida':
            ypred1=[[1,0,0, rdspend, administration, marketingspend]]
        os.chdir("C:\\Users\\user\\OneDrive\\Bureau")
        loaded_model = pickle.load(open('regressor1_model_test.sav', 'rb'))
        y_pred = loaded_model.predict(np.array(ypred1))
        Res=y_pred[0]
        Res=str(round(Res, 2))
        context= {'resultat': Res}
        return render(request,'templates/resultat.html',context)
        
def model2_predict(request):
    if request.method=="POST":
        rdspend=request.POST.get("RD Spend")       
        administration=request.POST.get("Administration")
        marketingspend=request.POST.get("Marketing Spend")
        state=request.POST.get("State")
        if state=='California':
            ypred1=[[0,0,1, rdspend, administration, marketingspend]]
        if state=='New York':
            ypred1=[[0,1,0, rdspend, administration, marketingspend]]
        if state=='Florida':
            ypred1=[[1,0,0, rdspend, administration, marketingspend]]
        os.chdir("C:\\Users\\user\\OneDrive\\Bureau")
        loaded_model = pickle.load(open('regressor2_model_test.sav', 'rb'))
        y_pred = loaded_model.predict(np.array(ypred1))
        Res=y_pred[0]
        Res=str(round(Res, 2))
        context= {'resultat': Res}
        return render(request,'templates/resultat.html',context)
