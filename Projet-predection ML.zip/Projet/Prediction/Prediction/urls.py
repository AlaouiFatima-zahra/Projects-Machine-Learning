from django.contrib import admin
from django.urls import path

from Prediction.views import index
from Prediction.views import model1_predict
from Prediction.views import model2_predict
from Prediction.views import acceuil
from Prediction.views import prediction1
from Prediction.views import prediction2

urlpatterns = [
    path('admin/', admin.site.urls),
    path('templates/',index),
    path('',acceuil),
    path('prediction1/',prediction1),
    path('prediction2/',prediction2),
    path('model1_predict/',model1_predict),
    path('model2_predict/',model2_predict),

]